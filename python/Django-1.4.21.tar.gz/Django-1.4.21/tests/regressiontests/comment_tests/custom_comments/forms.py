from django import forms


class CustomCommentForm(forms.Form):
    pass
