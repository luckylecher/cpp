"""
Unit-tests for the dispatch project
"""

from __future__ import absolute_import

from .test_dispatcher import DispatcherTests
from .test_saferef import SaferefTests
